#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char* dec2bin(unsigned int c);
extern int endian (unsigned int);
extern int reverse (unsigned int);
int main()
{
    
	unsigned int array_a[3];
	scanf("%x", &array_a[0]);
	scanf("%x", &array_a[1]);
	scanf("%x", &array_a[2]);
    
	printf("array_a[0]\t=\t%s\t%u\t%x\n",dec2bin(array_a[0]),array_a[0],array_a[0]);
	printf("array_a[1]\t=\t%s\t%u\t%x\n",dec2bin(array_a[1]),array_a[1],array_a[1]);
	printf("array_a[2]\t=\t%s\t%u\t%x\n\n",dec2bin(array_a[2]),array_a[2],array_a[2]);

	array_a[0]=  reverse(array_a[0]);
    	array_a[1] = reverse(array_a[1]);
    	array_a[2] = reverse(array_a[2]);
    	printf("BIT REVERSE ORDER\narray_a[0]\t=\t%s\t%u\t%x\n",dec2bin(array_a[0]),array_a[0],array_a[0]);
    	printf("array_a[1]\t=\t%s\t%u\t%x\n",dec2bin(array_a[1]),array_a[1],array_a[1]);
   	printf("array_a[2]\t=\t%s\t%u\t%x\n\n",dec2bin(array_a[2]),array_a[2],array_a[2]);

	array_a[0]=  reverse(array_a[0]);
    	array_a[1] = reverse(array_a[1]);
    	array_a[2] = reverse(array_a[2]);

    	array_a[0]=  endian(array_a[0]);
    	array_a[1] = endian(array_a[1]);
    	array_a[2] = endian(array_a[2]);
    	printf("ENDIAN CONVERSION\narray_a[0]\t=\t%s\t%u\t%x\n",dec2bin(array_a[0]),array_a[0],array_a[0]);
    	printf("array_a[1]\t=\t%s\t%u\t%x\n",dec2bin(array_a[1]),array_a[1],array_a[1]);
   	printf("array_a[2]\t=\t%s\t%u\t%x\n",dec2bin(array_a[2]),array_a[2],array_a[2]);

	return 0;
} 
char* dec2bin(unsigned int c)
{
    int i = 0;
    char *bin = (char*)malloc(sizeof(char)*31);
    for(i = 31; i >= 0; i--){
        if((c & (1 << i)) != 0){
            strcat(bin, "1");
        }else{
            strcat(bin, "0");
        }
    }
    return bin;
}
